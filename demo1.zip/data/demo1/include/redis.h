            
#ifndef REDIS_H
#define REDIS_H
#include <iostream>
#include <boost/asio.hpp>
#include <string>
#include "interop.h"
class RedisInterop:public Interop {
public:
    void Dump(boost::asio::streambuf& buffer, const std::string& source, int id, bool quiet) {
        std::istream is(&buffer);
        std::string line;
        while (std::getline(is, line)) {
            // 假设Redis命令以'*'开始
            if (source != "SERVER" && line.substr(0, 1) == "*") {
                int cmdCount = std::stoi(line.substr(1));
                std::string command;
                for (int j = 0; j < cmdCount * 2; ++j) {
                    std::getline(is, line);
                    if (j % 2 == 1) { // 只读取参数值，跳过参数长度
                        command += " " + line;
                    }
                }
                if (!quiet) {
                    std::cout << "[" << source << "-" << id << "] " << command << std::endl;
                }
            }
        }
        if (is.eof()) {
            // 清除EOF标志以继续读取
            is.clear();
        } else if (is.fail()) {
            // 如果发生错误，打印错误信息并退出
            std::cerr << "[" << source << "-" << id << "] read packet has an error, stop!!!" << std::endl;
            return;
        }
    }
};
#endif
