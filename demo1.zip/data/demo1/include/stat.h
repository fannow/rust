            

/*************************************************************************
        > File Name: include/stat.h
        > Author: username
        > Mail: 111111111@qq.com
        > Created Time: Mon Mar 11 15:48:20 2024
 ************************************************************************/

#ifndef STAT_H
#define STAT_H
#include <iostream>
#include <vector>
#include <netdb.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

// 定义一个Stater类，它是一个抽象类，包含了四个纯虚函数。
class Stater {
public:
    virtual void AddConn(std::string key, int conn) {};
    virtual void DelConn(std::string key) {};
    virtual void Start() {};
    virtual void Stop() {};
    virtual ~Stater() {}
};

// 定义一个compositeStater类，它继承自Stater类，并且包含了一个Stater类型的向量作为其成员变量。
class compositeStater : public Stater {
private:
    std::vector<Stater*> staters;
public:
    // 构造函数，接受一个可变参数包作为参数，将参数中的每个元素添加到向量中。
    template<typename... Args>
    compositeStater(Args... args) {
        // 使用初始化列表和逗号表达式将参数展开并添加到向量中。
        (staters.push_back(args), ...);
    }

    // 实现Stater类的纯虚函数，对向量中的每个元素调用相应的方法。
    void AddConn(std::string key, int conn)  {
        for (auto s : staters) {
            s->AddConn(key, conn);
        }
    }

    void DelConn(std::string key)  {
        for (auto s : staters) {
            s->DelConn(key);
        }
    }

    void Start() override {
        for (auto s : staters) {
            s->Start();
        }
    }

    void Stop() override {
        for (auto s : staters) {
            s->Stop();
        }
    }

    // 析构函数，释放向量中的每个元素的内存。
    ~compositeStater() {
        for (auto s : staters) {
            delete s;
        }
    }
};

// 定义一个NilPrinter类，它继承自Stater类，但是它的方法都是空的。
class NilPrinter : public Stater {
public:
    // 实现Stater类的纯虚函数，什么都不做。
    void AddConn(std::string key, int conn)  {}

    void DelConn(std::string key)  {}

    void Start() override {}

    void Stop() override {}
};

// 定义一个NewStater函数，它接受一个可变参数包作为参数，返回一个Stater类型的指针，指向一个compositeStater的实例。
template<typename... Args>
Stater* NewStater(Args... args) {
    // 创建一个compositeStater的实例，并将传入的参数作为其构造函数的参数。
    Stater* stat = new compositeStater(args...);

    // 启动一个子进程来监听中断信号和SIGTERM信号。
    pid_t pid = fork();
    if (pid == 0) {
        // 子进程
        // 创建一个sigset_t类型的变量c，并通过sigemptyset函数将其初始化为空集合。
        sigset_t c;
        sigemptyset(&c);

        // 通过sigaddset函数将SIGINT和SIGTERM信号添加到集合c中。
        sigaddset(&c, SIGINT);
        sigaddset(&c, SIGTERM);

        // 循环监听集合c，当接收到信号时执行相应的操作。
        int sig;
        while (true) {
            // 通过sigwait函数等待集合c中的任意一个信号，并将其存储在sig变量中。
            sigwait(&c, &sig);

            // 停止compositeStater的所有子Stater，并且向父进程发送相同的信号。
            stat->Stop();
            kill(getppid(), sig);
        }
    }

    // 返回创建的compositeStater实例作为Stater类型的指针。
    return stat;
}


#endif