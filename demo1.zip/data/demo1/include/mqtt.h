
                    
#ifndef MQTT_H
#define MQTT_H
#include <iostream>
#include <boost/asio.hpp>
#include "interop.h"
class MqttInterop:public Interop {
public:
    void Dump(boost::asio::streambuf& buffer, const std::string& source, int id, bool quiet) {
        // 从streambuf中读取数据
        std::istream is(&buffer);
        std::string line;
        while (std::getline(is, line)) {
            if (!quiet) {
                // 如果不是安静模式，打印消息
                std::cout << "[" << source << "-" << id << "] " << line << std::endl;
            }
        }
        if (is.eof()) {
            // 如果到达文件末尾，清除eof位以继续读取
            is.clear();
        } else if (is.fail()) {
            // 如果发生错误，打印错误信息并退出
            std::cerr << "[" << source << "-" << id << "] read packet has an error, stop!!!" << std::endl;
            return;
        }
    }
};
#endif
