
   #ifndef INTER_H // 使用 #ifndef 和 #define 宏来防止头文件被重复包含
#define INTER_H

#include <iostream>
#include <vector>
#include <memory>
#include <iomanip>
#include "print.h" // 假设display.h有类似的功能
#include "interop.h"
#include "mqtt.h"
#include "http2.h"
#include "redis.h"
#include "mongo.h"
namespace protocol{
const std::string ServerSide = "SERVER";


const int bufferSize = 1 << 20;

const std::string http2Protocol = "http2";
const std::string redisProtocol = "redis";
const std::string mongoProtocol = "mongo";
const std::string mqttProtocol = "mqtt";


class DefaultInterop : public Interop {
public:
  
    void Dump(boost::asio::streambuf& buffer, const std::string& source, int id, bool quiet) {
    // 创建一个istream来读取streambuf中的数据
    std::istream stream(&buffer);
    std::vector<unsigned char> buffer_data;

    // 循环直到没有更多数据可读
    while (!stream.eof()) {
        char c;
        stream.get(c); // 从stream中读取一个字符
        if (stream.good()) {
            buffer_data.push_back(static_cast<unsigned char>(c));
        }
    }

    // 如果不是静默模式，打印数据
    if (!quiet && !buffer_data.empty()) {
        std::cout << "from " << source << " [" << id << "]:\n";
        // 输出buffer_data中的数据为十六进制值
        for (auto c : buffer_data) {
            std::cout << std::setw(2) << std::setfill('0') << std::hex << static_cast<int>(c) << ' ';
        }
        std::cout << std::endl;
    }
}
};

Interop CreateInterop(const std::string& protocol) {
    if (protocol == grpcProtocol) {
        return  Http2Interop(new GrpcExplainer());
    } else if (protocol == http2Protocol) {
        return  Http2Interop();
    } else if (protocol == redisProtocol) {
       return   RedisInterop();
    } else if (protocol == mongoProtocol) {
         return  MongoInterop();
    } else if (protocol == mqttProtocol) {
        return  MqttInterop();
    } else {
        return  DefaultInterop();
    }
}
};
#endif