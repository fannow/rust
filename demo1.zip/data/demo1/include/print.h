
#ifndef PRINT_H
#define PRINT_H

/*
// 导入一些头文件，包括标准库和第三方库
#include <iostream>
#include <string>
#include <chrono>
#include <boost/format.hpp>
#include <boost/algorithm/string/join.hpp>

// 定义一个时间格式的常量
const std::string TimeFormat = "%H:%M:%S.%L";

// 定义一个display命名空间，包含两个函数，用于在终端中打印带有时间戳的信息
namespace display {

    // 定义一个PrintfWithTime函数，接受一个格式字符串和可变数量的参数，类似于标准库中的printf函数
    template <typename... Args>
    //template<typename... Args>
    void PrintfWithTime(const std::string& format, Args&&... args) {
        // 获取当前的时间，按照TimeFormat常量定义的格式，转换为字符串
        const std::string TimeFormat = "%Y-%m-%d %H:%M:%S";
        auto now = std::chrono::system_clock::now();
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
        auto now_time_t = std::chrono::system_clock::to_time_t(now);
        auto timer = std::put_time(std::localtime(&now_time_t), TimeFormat.c_str());
        std::stringstream ss;
        ss << timer << '.' << std::setfill('0') << std::setw(3) << ms.count();
        
        // 使用 boost::format 类来创建一个格式化对象
        boost::format fmt(format);
        // 使用重载的 % 运算符来传入参数
        (fmt % ... % std::forward<Args>(args)); // C++17 fold expression
        
        // 在格式化字符串前添加时间
        std::string output = ss.str() + " " + fmt.str();
        // 使用标准输出流，打印格式化后的字符串
        std::cout << output << std::endl;
    }

    
template <typename... Args>
void PrintlnWithTime(Args&&... args) {
    // 获取当前的时间，按照TimeFormat常量定义的格式，转换为字符串
    auto now = std::chrono::system_clock::now();
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
    auto now_time_t = std::chrono::system_clock::to_time_t(now);
    const std::string TimeFormat = "%Y-%m-%d %H:%M:%S"; // 你需要定义 TimeFormat
    auto timer = std::put_time(std::localtime(&now_time_t), TimeFormat.c_str());
    std::stringstream ss;
    ss << timer << '.' << std::setfill('0') << std::setw(3) << ms.count();

    // 直接在 std::cout 中打印时间戳和其他参数
    std::cout << ss.str() << " ";
    (std::cout << ... << std::forward<Args>(args)) << "\n";
}

}*/

#include <sstream>
#include <iomanip>
#include <iostream>
#include <chrono>
#include <boost/format.hpp>
#include <boost/algorithm/string/join.hpp>

// 定义日志宏，可以自动打印当前文件名和行号
#define PRINT_WITH_TIME(format, ...) display::PrintfWithTime(__FILE__, __LINE__, format, __VA_ARGS__)
#define PRINTLN_WITH_TIME(...) display::PrintlnWithTime(__FILE__, __LINE__, __VA_ARGS__)

namespace display {

    std::string getTimestamp() {
        // 获取当前的时间，按照TimeFormat常量定义的格式，转换为字符串
        const std::string TimeFormat = "%Y-%m-%d %H:%M:%S";
        auto now = std::chrono::system_clock::now();
        auto now_ms = std::chrono::time_point_cast<std::chrono::milliseconds>(now);
        auto epoch = now_ms.time_since_epoch();
        auto value = std::chrono::duration_cast<std::chrono::milliseconds>(epoch);
        std::time_t now_time_t = std::chrono::system_clock::to_time_t(now);
        std::stringstream ss;
        ss << std::put_time(std::localtime(&now_time_t), TimeFormat.c_str()) << '.' << std::setfill('0') << std::setw(3) << value.count() % 1000;
        return ss.str();
    }

// 打印带时间、文件名、行号的格式化信息
    template <typename... Args>
    void PrintfWithTime(const char* file, int line, const std::string& format, Args&&... args) {
        std::string timestamp = getTimestamp();

        // 使用 boost::format 类来创建一个格式化对象
        boost::format fmt(format);
        // 使用重载的 % 运算符来传入参数
        (fmt % ... % std::forward<Args>(args)); // C++17 fold expression

        // 在格式化字符串前添加时间戳、文件名和行号
        std::cout << timestamp << " [" << file << ":" << line << "] " << fmt.str() << std::endl;
    }

// 打印带时间、文件名、行号的信息
    template <typename... Args>
    void PrintlnWithTime(const char* file, int line, Args&&... args) {
        std::string timestamp = getTimestamp();
        // 直接在 std::cout 中打印时间戳和其他参数
        std::cout << timestamp << " [" << file << ":" << line << "] ";
        (std::cout << ... << std::forward<Args>(args)) << '\n';
    }

} // namespace display

#endif