/*************************************************************************
        > File Name: tcpstat_linux.h
        > Author: username
        > Mail: 111111111@qq.com
        > Created Time: Tue Mar 12 13:28:42 2024
 ************************************************************************/

#ifndef _TCPSTAT_LINUX_H
#define _TCPSTAT_LINUX_H
#include <iostream>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>

const double lostRateThreshold = 1e-6;

struct TcpInfo {
    uint8_t state;
    uint8_t ca_state;
    uint8_t retransmits;
    uint8_t probes;
    uint8_t backoff;
    uint8_t options;
    uint8_t w_scale;
    uint8_t app_limited;
    uint32_t rto;
    uint32_t ato;
    uint32_t snd_mss;
    uint32_t rcv_mss;
    uint32_t unacked;
    uint32_t sacked;
    uint32_t lost;
    uint32_t retrans;
    uint32_t fackets;
    uint32_t last_data_sent;
    uint32_t last_ack_sent;
    uint32_t last_data_recv;
    uint32_t last_ack_recv;
    uint32_t p_mtu;
    uint32_t rcv_ss_thresh;
    uint32_t rtt;
    uint32_t rtt_var;
    uint32_t snd_ss_thresh;
    uint32_t snd_cwnd;
    uint32_t adv_mss;
    uint32_t reordering;
    uint32_t rcv_rtt;
    uint32_t rcv_space;
    uint32_t total_retrans;
    int64_t pacing_rate;
    int64_t max_pacing_rate;
    int64_t bytes_acked;
    int64_t bytes_received;
    int32_t segs_out;
    int32_t segs_in;
    uint32_t notsent_bytes;
    uint32_t min_rtt;
    uint32_t data_segs_in;
    uint32_t data_segs_out;
    int64_t delivery_rate;
    int64_t busy_time;
    int64_t r_wnd_limited;
    int64_t snd_buf_limited;
    uint32_t delivered;
    uint32_t delivered_ce;
    int64_t bytes_sent;
    int64_t bytes_retrans;
    uint32_t d_sack_dups;
    uint32_t reord_seen;
};


TcpInfo* GetTcpInfo(boost::asio::basic_stream_socket<boost::asio::ip::tcp>* socket, std::error_code& ec) {
    if (!socket) {
        ec = std::make_error_code(std::errc::bad_file_descriptor);
        return nullptr;
    }

    int sock_fd = socket->native_handle();
    TcpInfo* tcp_info = new TcpInfo();
    socklen_t tcp_info_length = sizeof(TcpInfo);

    if (getsockopt(sock_fd, SOL_TCP, TCP_INFO, tcp_info, &tcp_info_length) != 0) {
        ec = std::make_error_code(std::errc::io_error);
        delete tcp_info;
        return nullptr;
    }

    return tcp_info;
}
double GetRetransRate(TcpInfo& pre_ti, const TcpInfo& ti) {
    if (pre_ti.bytes_sent == 0) {
        return 0;
    }

    int64_t bytes_delta = ti.bytes_sent - pre_ti.bytes_sent;
    double lost_rate = 0;
    if (bytes_delta != 0) {
        lost_rate = 100 * static_cast<double>(ti.bytes_retrans - pre_ti.bytes_retrans) / bytes_delta;
        if (lost_rate < lostRateThreshold) {
            lost_rate = 0;
        }
    }
    if (lost_rate < 0) {
        return 0;
    } else if (lost_rate > 1) {
        return 1;
    }

    return lost_rate;
}

std::pair<uint32_t, uint32_t> GetRTT(const TcpInfo& ti) {
    return {ti.rtt / 1000, ti.rtt_var / 1000};
}


#endif

                    