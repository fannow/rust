#ifndef COLOR_H
#define COLOR_H

#include <iostream>
#include <string>
#include <boost/format.hpp>

// 定义color类
class color {
private:
    // 颜色属性
    std::string code; // ANSI转义码

public:
    // 构造函数，接受一个ANSI转义码作为参数
    color(std::string code) {
        this->code = code;
    }

    // 静态成员函数，返回不同颜色的color对象
    static std::string black(const std::string& s) {
        return color("\033[30m" + s + "\033[0m").code;
    }
     static std::string red(const std::string& s) {
        return color("\033[31m" + s + "\033[0m").code;
    }
   

    static std::string green(const std::string& s) {
        return color("\033[32m" + s + "\033[0m").code;
    }

    static std::string yellow(const std::string& s) {
        return color("\033[33m" + s + "\033[0m").code;
    }

    static std::string blue(const std::string& s) {
        return color("\033[34m" + s + "\033[0m").code;
    }

    static std::string magenta(const std::string& s) {
        return color("\033[35m" + s + "\033[0m").code;
    }

    static std::string cyan(const std::string& s) {
        return color("\033[36m" + s + "\033[0m").code;
    }

    static std::string white(const std::string& s) {
        return color("\033[37m" + s + "\033[0m").code;
    }

    // 重载()运算符，接受一个std::string类型的参数，返回带颜色的字符串
    std::string operator()(std::string s) {
        return code + s + "\033[0m";
    }

    // 重载()运算符，接受一个boost::basic_format<char>::string_type类型的参数，返回带颜色的字符串
    std::string operator()(const boost::basic_format<char>::string_type& s) {
        return code + s + "\033[0m";
    }
};

#endif
