

#ifndef HTTP2_H
#define HTTP2_H
#include <nghttp2/nghttp2.h>
#include <tuple>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
#include <boost/format.hpp>
#include <iostream>
#include <boost/asio.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/hex.hpp>
#include <boost/optional.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <boost/property_tree/json_parser.hpp>
#include "grpc.h"
#include "interop.h"

    const std::string grpcProtocol = "grpc";
    const std::string ClientSide = "CLIENT";
    const int http2HeaderLen = 9;
    const std::string http2Preface = "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n";
    const int http2SettingsPayloadLen = 6;

    class Http2Interop:public Interop{
    private:
        DataExplainer* explainer;

    public:
        
        Http2Interop(DataExplainer* explainer=NULL) : explainer(explainer) {}

        // void Dump(boost::asio::streambuf& buffer, const std::string& source, int id, bool quiet) {
        //     readPreface(buffer, source, id);

        //     std::vector<uint8_t> data(boost::asio::buffer_size(buffer.data()));
        //     boost::asio::buffer_copy(boost::asio::buffer(data), buffer.data());

        //     std::size_t bytesRead = data.size();
        //     std::size_t index = 0;
        //     while (bytesRead > 0) {
        //         std::size_t n = std::min(bytesRead, static_cast<std::size_t>(buffer.size()));
        //         std::vector<uint8_t> frameData(data.begin() + index, data.begin() + index + n);
        //         if (n > 0 && !quiet) {
        //             std::stringstream ss;
        //             ss << "from " << source << " [" << id << "]\n";
        //             std::string header = ss.str();

        //             std::string frameInfo, moreInfo;
        //             int offset;
        //             std::tie(frameInfo, moreInfo, offset) = explain(frameData);

        //             std::stringstream buf;
        //             buf << boost::format("%s%s%s\n") % boost::io::blue << grpcProtocol % boost::io::yellow << frameInfo % boost::io::blue;
        //             buf << boost::algorithm::hex_dump(frameData.data(), frameData.data() + offset);

        //             if (!moreInfo.empty()) {
        //                 buf << "\n" << boost::algorithm::trim_copy(moreInfo) << "\n\n";
        //             }

        //             std::cout << boost::algorithm::trim_copy(header + buf.str()) << std::endl;
        //         }
        //         bytesRead -= n;
        //         index += n;
        //     }
        // }



void Dump(boost::asio::streambuf& buffer, const std::string& source, int id, bool quiet) {
    readPreface(buffer, source, id);

    std::vector<uint8_t> data(
        boost::asio::buffers_begin(buffer.data()),
        boost::asio::buffers_begin(buffer.data()) + buffer.size()
    );

    std::size_t index = 0;
    while (index < data.size()) {
        std::size_t n = std::min((std::size_t)buffer.size(), data.size() - index);
        std::vector<uint8_t> frameData(data.begin() + index, data.begin() + index + n);
        if (n > 0 && !quiet) {
            std::stringstream ss;
            ss << "from " << source << " [" << id << "]\n";
            std::string header = ss.str();

            std::string frameInfo, moreInfo;
            int offset;
            std::tie(frameInfo, moreInfo, offset) = explain(frameData);

            std::stringstream buf;
            // 以下是使用 boost 库格式化输出的示例
            buf << boost::format("<<blue>>%s<<reset>>:<<(yellow)>>%s<<reset>>\n") % grpcProtocol % frameInfo;
            // buf << boost::algorithm::hex(frameData.begin(), frameData.begin() + offset);
            std::string hexData;
             boost::algorithm::hex(frameData.begin(), frameData.begin() + offset, std::back_inserter(hexData));
             buf << hexData;
            if (!moreInfo.empty()) {
                buf << "\n" << boost::algorithm::trim_copy(moreInfo) << "\n\n";
            }

            std::cout << boost::algorithm::trim_copy(header + buf.str()) << std::endl;
        }
        index += n;
    }
}

// std::tuple<std::string, std::string, int> explain(const std::vector<uint8_t>& data) {
//     if (data.size() < http2HeaderLen) {
//         return std::make_tuple("", "", data.size());
//     }

//     std::string frameType = "http2";
//     std::string frameInfo;
//     std::string moreInfo;
//     int frameLen = http2HeaderLen + data[0] + (data[1] << 8) + (data[2] << 16);
//     int maxOffset = std::min(frameLen, static_cast<int>(data.size()));

//     // 使用 nghttp2 的常量来替换原有的 http2.FrameSettings 等
//     switch (data[3]) {
//         case NGHTTP2_SETTINGS:
//             switch (data[4]) {
//                 case NGHTTP2_FLAG_ACK:
//                     frameInfo = "http2:settings:ack";
//                     break;
//                 default:
//                     frameInfo = explainSettings(data);
//                     break;
//             }
//             break;
//         case NGHTTP2_PING:
//             {
//                 // std::string id = boost::algorithm::hex(data.begin() + http2HeaderLen, data.begin() + maxOffset);
//                  std::string id;
//                  boost::algorithm::hex(data.begin(), data.end(), std::back_inserter(id));
//                 switch (data[4]) {
//                     case NGHTTP2_FLAG_ACK:
//                         frameInfo = boost::str(boost::format("http2:ping:ack %s") % id);
//                         break;
//                     default:
//                         frameInfo = boost::str(boost::format("http2:ping %s") % id);
//                         break;
//                 }
//             }
//             break;
//         case NGHTTP2_WINDOW_UPDATE:
//             {
//                 uint32_t increment = (data[5] << 24) + (data[6] << 16) + (data[7] << 8) + data[8];
//                 frameInfo = boost::str(boost::format("http2:window_update window_size_increment:%d") % increment);
//             }
//             break;
//         case NGHTTP2_HEADERS:
//             {
//                 std::tie(frameInfo, moreInfo) = explainHeaders(data);
//             }
//             break;
//         case NGHTTP2_DATA:
//             {
//                 if (data[4] == NGHTTP2_FLAG_END_STREAM) {
//                      if (explainer) {
//                          moreInfo = this->explainer->explain(std::vector<uint8_t>(data.begin() + http2HeaderLen, data.begin() + maxOffset));
//                    }
//                     frameInfo = boost::str(boost::format("http2:data stream:%1% len:%2% end_stream") %
//                         boost::algorithm::to_lower_copy(http2.FrameData) % data[5] % (frameLen - http2HeaderLen));
                   
//                 } else {
//                     frameInfo = boost::str(boost::format("http2:data stream:%1% len:%2%") %
//                         boost::algorithm::to_lower_copy(http2.FrameData) % data[5] % (frameLen - http2HeaderLen));
//                 }
//             }
//             break;
//         default:
//             if (data[5] > 0) {
//                 frameInfo = boost::str(boost::format("http2:%1% stream:%2% len:%3%") %
//                     boost::algorithm::to_lower_copy(frameType) % data[5] % (frameLen - http2HeaderLen));
//             } else {
//                 frameInfo = boost::str(boost::format("http2:%1%") % boost::algorithm::to_lower_copy(frameType));
//             }
//             break;
//     }

//     return std::make_tuple(frameInfo, moreInfo, frameLen);
// }


std::tuple<std::string, std::string, int> explain(const std::vector<uint8_t>& data) {
    if (data.size() < http2HeaderLen) {
        return std::make_tuple("", "", data.size());
    }

    std::string frameType = "http2";
    std::string frameInfo;
    std::string moreInfo;
    int frameLen = http2HeaderLen + data[0] + (data[1] << 8) + (data[2] << 16);
    int maxOffset = std::min(frameLen, static_cast<int>(data.size()));

    // 使用 nghttp2 的常量来替换原有的 http2.FrameSettings 等
    switch (data[3]) {
        case NGHTTP2_SETTINGS:
            switch (data[4]) {
                case NGHTTP2_FLAG_ACK:
                    frameInfo = "http2:settings:ack";
                    break;
                default:
                    frameInfo = explainSettings(data);
                    break;
            }
            break;
        case NGHTTP2_PING:
            {
                std::string id;
                boost::algorithm::hex(data.begin() + http2HeaderLen, data.begin() + maxOffset, std::back_inserter(id));
                switch (data[4]) {
                    case NGHTTP2_FLAG_ACK:
                        frameInfo = boost::str(boost::format("http2:ping:ack %s") % id);
                        break;
                    default:
                        frameInfo = boost::str(boost::format("http2:ping %s") % id);
                        break;
                }
            }
            break;
        case NGHTTP2_WINDOW_UPDATE:
            {
                uint32_t increment = (data[5] << 24) + (data[6] << 16) + (data[7] << 8) + data[8];
                frameInfo = boost::str(boost::format("http2:window_update window_size_increment:%d") % increment);
            }
            break;
        case NGHTTP2_HEADERS:
            {
                std::tie(frameInfo, moreInfo) = explainHeaders(data);
            }
            break;
        case NGHTTP2_DATA:
            {
                if (data[4] == NGHTTP2_FLAG_END_STREAM) {
                     if (explainer) {
                         moreInfo = this->explainer->explain(std::vector<uint8_t>(data.begin() + http2HeaderLen, data.begin() + maxOffset));
                   }
                    frameInfo = boost::str(boost::format("http2:data stream:%1% len:%2% end_stream") %
                        boost::algorithm::to_lower_copy(frameType) % data[5] % (frameLen - http2HeaderLen));
                   
                } else {
                    frameInfo = boost::str(boost::format("http2:data stream:%1% len:%2%") %
                        boost::algorithm::to_lower_copy(frameType) % data[5] % (frameLen - http2HeaderLen));
                }
            }
            break;
        default:
            if (data[5] > 0) {
                frameInfo = boost::str(boost::format("http2:%1% stream:%2% len:%3%") %
                    boost::algorithm::to_lower_copy(frameType) % data[5] % (frameLen - http2HeaderLen));
            } else {
                frameInfo = boost::str(boost::format("http2:%1%") % boost::algorithm::to_lower_copy(frameType));
            }
            break;
    }

    return std::make_tuple(frameInfo, moreInfo, frameLen);
}



// std::tuple<std::string, std::string> explainHeaders(const std::vector<uint8_t>& data) {
//     // 确保 data 至少有 http2HeaderLen + 1 的长度
//     if (data.size() < http2HeaderLen + 1) {
//         return std::make_tuple("", "");
//     }

//     // 解析 Stream ID，通常是 4 个字节的整数
//     uint32_t stream_id = nghttp2_get_uint32(&data[5]) & 0x7FFFFFFFu;

//     std::string frameInfo = "http2:headers stream:" + std::to_string(stream_id);
//     std::string moreInfo;

//     if (data[4] & NGHTTP2_FLAG_PADDED) {
//         int padded = data[http2HeaderLen];
//         std::vector<uint8_t> headersData(data.begin() + http2HeaderLen + 1, data.end() - padded);
//         moreInfo = explainHeaderFields(headersData);
//     } else {
//         std::vector<uint8_t> headersData(data.begin() + http2HeaderLen, data.end());
//         moreInfo = explainHeaderFields(headersData);
//     }

//     return std::make_tuple(frameInfo, moreInfo);
// }
const int http2HeaderLen = 9; // HTTP/2 head length
const uint8_t NGHTTP2_FLAG_PADDED = 0x08; // Padded flag

std::tuple<std::string, std::string> explainHeaders(const std::vector<uint8_t>& data) {
    // Ensure data is at least http2HeaderLen + 1 in length
    if (data.size() < http2HeaderLen + 1) {
        return std::make_tuple("", "");
    }

    // Parse Stream ID, usually a 4-byte integer
    uint32_t stream_id = ((data[5] << 24) | (data[6] << 16) | (data[7] << 8) | data[8]) & 0x7FFFFFFFu;

    std::string frameInfo = "http2:headers stream:" + std::to_string(stream_id);
    std::string moreInfo;

    if (data[4] & NGHTTP2_FLAG_PADDED) {
        int padded = data[http2HeaderLen];
        std::vector<uint8_t> headersData(data.begin() + http2HeaderLen + 1, data.end() - padded);
        moreInfo = explainHeaderFields(headersData);
    } else {
        std::vector<uint8_t> headersData(data.begin() + http2HeaderLen, data.end());
        moreInfo = explainHeaderFields(headersData);
    }

    return std::make_tuple(frameInfo, moreInfo);
}



// ...这里可能会有对 explainHeaderFields 函数的具体实现

// std::string explainHeaderFields(const std::vector<uint8_t>& data) {
//     std::stringstream ss;
//     // 使用 nghttp2 的解码器
//     nghttp2_hd_inflater *inflater;
//     nghttp2_hd_inflate_new(&inflater);

//     std::vector<nghttp2_nv> nv;
//     size_t nvlen;
//     int rv = nghttp2_hd_inflate_hd(inflater, &nv, &nvlen, data.data(), data.size(), 1);

//     if (rv < 0) {
//         // 如果解码失败，释放 inflater 并返回空字符串
//         nghttp2_hd_inflate_del(inflater);
//         return "";
//     }

//     for (size_t i = 0; i < nvlen; ++i) {
//         ss << nv[i].name << ": " << nv[i].value << "\n";
//     }

//     // 释放 inflater
//     nghttp2_hd_inflate_del(inflater);

//     return ss.str();
// }



std::string explainHeaderFields(const std::vector<uint8_t>& data) {
    std::stringstream ss;
    
    // 初始化 nghttp2 HD 解压器
    nghttp2_hd_inflater *inflater;
    nghttp2_hd_inflate_new(&inflater);

    // 准备缓冲区存放解压后的名称-值对
    nghttp2_nv nv[100];
    int nvlen;
    
    // 使用内置的 nghttp2 函数解码头部块
    // 使用 const_cast 移除 const 限定
    uint8_t* mutable_data = const_cast<uint8_t*>(data.data());
    int rv = nghttp2_hd_inflate_hd(inflater, nv, &nvlen, mutable_data, data.size(), 1);

    if (rv < 0) {
        // 如果解码失败，释放解压器并返回空字符串
        nghttp2_hd_inflate_del(inflater);
        return "";
    }

    for (int i = 0; i < nvlen; ++i) {
        ss << nv[i].name << ": " << nv[i].value << "\n";
    }

    // 释放解压器
    nghttp2_hd_inflate_del(inflater);

    return ss.str();
}
std::string explainSettings(const std::vector<uint8_t>& data) {
    std::stringstream ss;
    ss << "http2:settings";

    // Create an inflater for decoding the settings.
    nghttp2_hd_inflater *inflater;
    nghttp2_hd_inflate_new(&inflater);

    // Iterate over the data and process settings payload.
    for (size_t i = 0; i < data.size(); i += 6) {
        // The settings ID and value are encoded in network byte order.
        uint16_t id = ntohs(*reinterpret_cast<const uint16_t*>(&data[i]));
        uint32_t value = ntohl(*reinterpret_cast<const uint32_t*>(&data[i + 2]));

        switch (id) {
            case NGHTTP2_SETTINGS_HEADER_TABLE_SIZE:
                ss << " header_table_size:" << value;
                break;
            case NGHTTP2_SETTINGS_ENABLE_PUSH:
                ss << " enable_push:" << value;
                break;
            case NGHTTP2_SETTINGS_MAX_CONCURRENT_STREAMS:
                ss << " max_concurrent_streams:" << value;
                break;
            case NGHTTP2_SETTINGS_INITIAL_WINDOW_SIZE:
                ss << " initial_window_size:" << value;
                break;
            case NGHTTP2_SETTINGS_MAX_FRAME_SIZE:
                ss << " max_frame_size:" << value;
                break;
            case NGHTTP2_SETTINGS_MAX_HEADER_LIST_SIZE:
                ss << " max_header_list_size:" << value;
                break;
            // Add more cases as needed for other settings.
        }
    }

    // Free the inflater after use.
    nghttp2_hd_inflate_del(inflater);

    return ss.str();
}

        // void readPreface(boost::asio::streambuf& buffer, const std::string& source, int id) {
        //     if (source != ClientSide) {
        //         return;
        //     }

        //     std::string preface(boost::asio::buffer_cast<const char*>(buffer.data()), http2Preface.length());
        //     if (preface != http2Preface) {
        //         return;
        //     }

        //     std::cout << std::endl;
        //     std::string header = boost::str(boost::format("from %s [%d]\n") % source % id);
        //     std::string frameInfo = boost::str(boost::format("%1%%2%%3%\n") % boost::io::blue % grpcProtocol % boost::io::blue);
        //     std::string hexDump = boost::algorithm::hex_dump(preface);
        //     std::cout << boost::algorithm::trim_copy(header + frameInfo + hexDump) << std::endl;
        // }

    void readPreface(boost::asio::streambuf&r, const std::string& source, int id) {
        if (source != ClientSide) {
            return;
        }

        std::string preface;
        std::istream stream(&r);
        std::getline(stream, preface);
        if (preface != http2Preface) {
            return;
        }

        std::cout << std::endl;
        // std::string header = boost::str(boost::format("from %s [%d]\n", source.c_str(), id));
        std::string header = boost::str(boost::format("from %1% [%2%]\n") % source % id);
        // std::string frameInfo = boost::str(boost::format("%s:(", grpcProtocol.c_str()));
        std::string frameInfo = boost::str(boost::format("%1%:(") % grpcProtocol);
        // std::string hexDump = boost::algorithm::hex(preface.begin(), preface.end());
        std::string hexDump;
        boost::algorithm::hex(preface.begin(), preface.end(), std::back_inserter(hexDump));
        std::string trimmedStr = boost::algorithm::trim_copy(header + frameInfo + hexDump);
        std::cout << trimmedStr << ")\n\n";
    }
};



#endif
            