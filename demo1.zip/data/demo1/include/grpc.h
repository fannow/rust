
#ifndef GRPC_H
#define GRPC_H
#include <google/protobuf/io/coded_stream.h>
#include <google/protobuf/wire_format_lite.h>
#include <iterator>
#include <string>
#include <vector>

const int grpcHeaderLen = 5;

class DataExplainer {
public:
    virtual std::string explain(const std::vector<uint8_t>& data) = 0;
};

class GrpcExplainer : public DataExplainer {
public:
    std::string explain(const std::vector<uint8_t>& b) override {
        if (b.size() < grpcHeaderLen) {
            return "";
        }

        if (b[0] == 1) {
            return "";
        }

        auto it = b.begin() + 1;
        uint32_t size = (it[0] << 24) | (it[1] << 16) | (it[2] << 8) | it[3];
        it += 4;
        if (std::distance(it, b.end()) < size) {
            return "";
        }

        std::string result;
        ExplainFields(std::vector<uint8_t>(it, it + size), result, 0);
        return result;
    }

private:
    bool ExplainFields(const std::vector<uint8_t>& b, std::string& result, int depth) {
        google::protobuf::io::CodedInputStream input(b.data(), b.size());
        while (!input.ExpectAtEnd()) {
            uint32_t tag = input.ReadTag();
            auto type = google::protobuf::internal::WireFormatLite::GetTagWireType(tag);
            int field_number = google::protobuf::internal::WireFormatLite::GetTagFieldNumber(tag);

            switch (type) {
                case google::protobuf::internal::WireFormatLite::WIRETYPE_VARINT: {
                    uint64_t value;
                    if (!input.ReadVarint64(&value)) {
                        return false;
                    }
                    Write(result, "#" + std::to_string(field_number) + ": (varint)\n", depth);
                    break;
                }
                case google::protobuf::internal::WireFormatLite::WIRETYPE_FIXED32: {
                    uint32_t value;
                    if (!input.ReadLittleEndian32(&value)) {
                        return false;
                    }
                    Write(result, "#" + std::to_string(field_number) + ": (fixed32)\n", depth);
                    break;
                }
                case google::protobuf::internal::WireFormatLite::WIRETYPE_FIXED64: {
                    uint64_t value;
                    if (!input.ReadLittleEndian64(&value)) {
                        return false;
                    }
                    Write(result, "#" + std::to_string(field_number) + ": (fixed64)\n", depth);
                    break;
                }
                case google::protobuf::internal::WireFormatLite::WIRETYPE_LENGTH_DELIMITED: {
                    std::string nested_result;
                    uint32_t length;
                    if (!input.ReadVarint32(&length)) {
                        return false;
                    }
                    auto limit = input.PushLimit(length);
                    if (ExplainFields(std::vector<uint8_t>(b.begin(), b.begin() + length), nested_result, depth + 1)) {
                        Write(result, "#" + std::to_string(field_number) + ":\n", depth);
                        result += nested_result;
                    } else {
                        Write(result, "#" + std::to_string(field_number) + ": " + nested_result + "\n", depth);
                    }
                    input.PopLimit(limit);
                    break;
                }
                default:
                   // input.Skip(tag);
                    break;
            }
        }
        return true;
    }

    void Write(std::string& result, const std::string& val, int depth) {
        for (int i = 0; i < depth; i++) {
            result += "  ";
        }
        result += val;
    }
};
#endif