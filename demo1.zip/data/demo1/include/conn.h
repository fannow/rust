#ifndef _CONN_H
#define _CONN_H
#include"inter.h"
// 包含一些必要的头文件
#include <iostream>
#include <string>
#include <thread>
#include <mutex>
#include <boost/circular_buffer.hpp>
#include <atomic>
#include <chrono>
#include <map>
#include<memory>
#include <boost/asio.hpp>
#include <boost/asio/spawn.hpp>
#include <boost/asio/steady_timer.hpp>
#include <boost/system/error_code.hpp>
#include <boost/system/system_error.hpp>
#include <boost/exception/all.hpp>
#include <boost/format.hpp>
#include <boost/lexical_cast.hpp>
#include "print.h"
#include "stat_linux.h"
#include "conter.h"
#include "color.h"
#include "settings.h"
#include "stat.h"

class color;
using namespace std;
using namespace boost::asio;
using namespace boost::system;
class DeferStop {
public:
    std::function<void()> func;

    // 构造函数接收一个函数对象
    DeferStop(std::function<void()> f) : func(f) {}

    // 析构函数调用该函数对象
    ~DeferStop() {
        func();
    }
};

// 定义一些常量
const string useOfClosedConn = "use of closed network connection";
const auto statInterval = std::chrono::seconds(5);

boost::system::error_code errClientCanceled = boost::system::errc::make_error_code(boost::system::errc::operation_canceled);


io_context ioc;

Stater *stater;
 //std::shared_ptr<Stater> stater = std::make_shared<Stater>();


class PairedConnection {
public:
 
PairedConnection(int id, ip::tcp::socket cliConn, boost::asio::io_context& ioc) 
    : id(id), cliConn(move(cliConn)), svrConn(ioc), stopFlag(false), stopChan(false) {


}

/*
  void copyData(boost::asio::ip::tcp::socket& dst, boost::asio::ip::tcp::socket& src, const std::string& tag) {
    boost::system::error_code ec;
   
    boost::asio::streambuf buffer;
 
    while (boost::asio::read(src, buffer.prepare(4096), boost::asio::transfer_at_least(1), ec)) {
        buffer.commit(ec.value());
        if (!ec || ec == boost::asio::error::eof) {
          
            boost::asio::write(dst, buffer.data(), ec);
            buffer.consume(buffer.size());
            if (ec) {
                if (ec != boost::asio::error::eof) {
                
                    PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s error, %s") % id % tag % ec.message()).str()));
                }
                break;
            }
        } else {
            
            PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s error, %s") % id % tag % ec.message()).str()));
            break;
        }
    }
}*/
// void copyData(boost::asio::ip::tcp::socket& dst, boost::asio::ip::tcp::socket& src, const std::string& tag,boost::asio::streambuf& buffer) {
 
          
//             boost::system::error_code ec;
//             while (!stopFlag&&!ec) {
//                 // 尝试读取客户端数据，直到读取完毕或出现错误
                 
//                 std::size_t bytes_to_read = src.available();
//                 if(bytes_to_read==0){
//                     break;
//                 }
//                 std::size_t bytes_transferred = boost::asio::read(src, buffer.prepare(bytes_to_read ),ec);
               

//                     if (ec) {
//                             if (ec != boost::asio::error::eof) {

//                                 PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s error, %s") % id % tag % ec.message()).str()));
//                             }
//                             break;
//                         }
//                     } else {

//                         PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s error, %s") % id % tag % ec.message()).str()));
//                         break;
//                     }

//                 buffer.commit(bytes_transferred); // 将数据从输入序列移动到输出序列

//             }
//             std::string data(std::istreambuf_iterator<char>(&buffer), {});

//             PRINT_WITH_TIME("读取到的数据：%s",data);  
//             if (tag == "CLIENT") {

//                     boost::asio::write(dst, buffer.data(), ec);
//                     buffer.consume(buffer.size());
//             } else {
//                     //如果是服务端发送数据就延迟写入
//                     if (stopChan) {
//                         throw std::runtime_error("Client cancelled");

//                     } else {
//                         if (settings.delay >  boost::chrono::milliseconds(0)) {
//                            std::this_thread::sleep_for(std::chrono::milliseconds(settings.delay.count()));

//                             boost::asio::write(dst, buffer.data(), ec);
//                             buffer.consume(buffer.size());
//                         }
//                     }
//                 }
//         // boost::system::error_code ec;
//         // std::size_t bytes_to_read = src.available();
//         // std::cout << "可读取数据："<<bytes_to_read<< std::endl;
//         // while (boost::asio::read(src, buffer.prepare(bytes_to_read), ec)) {
//         //     buffer.commit(ec.value());
//         //     if (!ec || ec == boost::asio::error::eof) {

//         //     std::string data(std::istreambuf_iterator<char>(&buffer), {});

//         //     PRINT_WITH_TIME("读取到的数据：%s",data);
//         //         if (tag == "CLIENT") {

//         //             boost::asio::write(dst, buffer.data(), ec);
//         //             buffer.consume(buffer.size());
//         //         } else {
//         //             //如果是服务端发送数据就延迟写入
//         //             if (stopChan) {
//         //                 throw std::runtime_error("Client cancelled");

//         //             } else {
//         //                 if (settings.delay >  boost::chrono::milliseconds(0)) {
//         //                    std::this_thread::sleep_for(std::chrono::milliseconds(settings.delay.count()));

//         //                     boost::asio::write(dst, buffer.data(), ec);
//         //                     buffer.consume(buffer.size());
//         //                 }
//         //             }
//         //         }
//         //             if (ec) {
//         //                 if (ec != boost::asio::error::eof) {

//         //                     PRINTLN_WITH_TIME(
//         //                             color::red((boost::format("[%d] %s error, %s") % id % tag % ec.message()).str()));
//         //                 }
//         //                 break;
//         //             }
//         //         } else {

//         //             PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s error, %s") % id % tag % ec.message()).str()));
//         //             break;
//         //         }
//         //     }
          
//         }
    void copyData(boost::asio::ip::tcp::socket& dst, boost::asio::ip::tcp::socket& src, const std::string& tag,boost::asio::streambuf& buffer) {
 
          
            boost::system::error_code ec;
            std::cout << " local endpoint: " << src.local_endpoint()
                      << ", remote endpoint: " << src.remote_endpoint() << std::endl;
            while (!ec) {
                // 尝试读取客户端数据，直到读取完毕或出现错误
                 
                std::size_t bytes_to_read = src.available();
                PRINT_WITH_TIME("数据长度%d",bytes_to_read); 
                 if(bytes_to_read==0){
                     break;
                 }
                
                std::size_t bytes_transferred = boost::asio::read(src, buffer.prepare(bytes_to_read ),ec);
               

                    if (ec) {
                            if (ec != boost::asio::error::eof) {

                                PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s error, %s") % id % tag % ec.message()).str()));
                            }else{
                                 PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s error, %s") % id % tag % ec.message()).str()));
                            }
                            break;
                        
                    } 

                buffer.commit(bytes_transferred); // 将数据从输入序列移动到输出序列

            }
            std::string data(std::istreambuf_iterator<char>(&buffer), {});

            PRINT_WITH_TIME("读取到的数据：%s",data);  
            if (tag == "CLIENT") {

                    size_t bytes_transferred=boost::asio::write(dst, buffer.data(), ec);
                    buffer.consume(buffer.size());
                    if (bytes_transferred != buffer.size()) {
                        std::cout << "Not all data was written!" << std::endl;
                    } else {
                        std::cout << "Data written successfully." << std::endl;
                    }
                     PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s 发送, %s") % id % tag % ec.message()).str()));
            } else {
                    //如果是服务端发送数据就延迟写入
                    if (stopChan) {
                        throw std::runtime_error("Client cancelled");

                    } else {
                        if (settings.delay >  boost::chrono::milliseconds(0)) {
                           std::this_thread::sleep_for(std::chrono::milliseconds(settings.delay.count()));

                            size_t bytes_transferred=boost::asio::write(dst, buffer.data(), ec);
                            buffer.consume(buffer.size());
                             if (bytes_transferred != buffer.size()) {
                        std::cout << "Not all data was written!" << std::endl;
                    } else {
                        std::cout << "Data written successfully." << std::endl;
                    }
                     PRINTLN_WITH_TIME(color::red((boost::format("[%d] %s 发送, %s") % id % tag % ec.message()).str()));
                        }
                    }
                }
       
        }
#include"ratelimt.h"
         void copyDataWithRateLimit(boost::asio::ip::tcp::socket &dst, boost::asio::ip::tcp::socket &src,
                                   const std::string &tag, int64_t limit,boost::asio::streambuf& buffer) {
           
            if (limit > 0) {
                rate_limited_socket rls(src, limit);
                std::vector<char> all_data;
                std::size_t bytes_transferred;
              // boost::asio::streambuf buffer;
                // 将数据从源读取并存储至all_data中。
                
               while ((bytes_transferred = rls.readSome(buffer.prepare(1024))) > 0) {
                buffer.commit(bytes_transferred);
            
                buffer.consume(bytes_transferred);
              }



                if (tag == "CLIENT") {

                    boost::asio::write(dst,buffer.data());
                } else {
                    //如果是服务端发送数据就延迟写入
                    if (stopChan) {
                        throw std::runtime_error("Client cancelled");

                    } else {
                        if (settings.delay >  boost::chrono::milliseconds(0)) {
                            std::this_thread::sleep_for(std::chrono::milliseconds(settings.delay.count()));
                           boost::asio::write(dst,buffer.data());
                        }
                    }


                }
            } else {
                copyData(dst, src, tag,buffer);
            }
        
        }
    

/*
void copyDataWithRateLimit(boost::asio::ip::tcp::socket& dst, boost::asio::ip::tcp::socket& src, const std::string& tag, int64_t limit) {
    if (limit > 0) {
        rate_limited_socket rls(src, limit);
        boost::asio::streambuf buffer;
        while (std::size_t bytes_transferred = rls.readSome(buffer.prepare(1024))) {
            buffer.commit(bytes_transferred);
            boost::asio::write(dst, buffer.data());
            buffer.consume(bytes_transferred);
        }
    }
    else {
        copyData(dst, src, tag); 
    }
   }*/
   
/* void handleClientMessage() {
    
        DeferStop deferStop(std::bind(&PairedConnection::stop, this));
        std::cout<<"处理客户端信息"<<std::endl;
        boost::asio::streambuf buffer;
        std::ostream os(&buffer);
        std::istream is(&buffer);
        std::string data;
        std::getline(is, data);
        std::cout << data << std::endl;
        
        boost::asio::streambuf::const_buffers_type bufs = buffer.data();

        std::size_t bytes_transferred = boost::asio::write(svrConn, bufs);
        os.write(boost::asio::buffer_cast<const char*>(bufs), bytes_transferred);
        auto interop = protocol::CreateInterop(settings.protocol); 
        interop.Dump(buffer, ClientSide, id, settings.quiet);

        copyDataWithRateLimit(svrConn, cliConn, ClientSide, settings.uplimit);
    }
    */
    /*
void handleClientMessage() {
      std::cout << "svrConn local endpoint: " << svrConn.local_endpoint()
                  << ", remote endpoint: " << svrConn.remote_endpoint() << std::endl;
      std::cout << "cliConn local endpoint: " << cliConn.local_endpoint() 
                  << ", remote endpoint: " << cliConn.remote_endpoint() << std::endl;
      //DeferStop deferStop(std::bind(&PairedConnection::stop, this));
      DeferStop deferStop([this](){ this->stop();  });
      boost::asio::streambuf buffer;
      std::ip_address_stream is(&buffer);
      std::ostream os(&buffer);

                    
      std::size_t bytes_transferred = boost::asio::read(cliConn, buffer.prepare(1000));
      buffer.commit(bytes_transferred);
      std::istream is1(&buffer);
      //std::string data1;
      std::string data(std::istreambuf_iterator<char>(&buffer), {});

      std::cout << data << std::endl;
      boost::asio::write(svrConn, buffer.data());

                                
      auto interop = protocol::CreateInterop(settings.protocol); 
      interop.Dump(buffer, ClientSide, id, settings.quiet);

                                        
      copyDataWithRateLimit(svrConn, cliConn, ClientSide, settings.uplimit);

}*/
 void handleClientMessage() {

            std::cout << "svrConn local endpoint: " << svrConn.local_endpoint()
                      << ", remote endpoint: " << svrConn.remote_endpoint() << std::endl;
            std::cout << "cliConn local endpoint: " << cliConn.local_endpoint()
                      << ", remote endpoint: " << cliConn.remote_endpoint() << std::endl;

            //aDeferStop deferStop([this](){ this->stop();  });

            // boost::system::error_code ec;
            // boost::asio::streambuf buffer;
            // while (!ec) {
            //     // 尝试读取客户端数据，直到读取完毕或出现错误
            //      std::size_t bytes_to_read = cliConn.available();

            //     std::cout << "客户端可读的字节数: " <<bytes_to_read << std::endl;
            //       if(bytes_to_read==0){
            //         break;
            //     }
            //     std::size_t bytes_transferred = boost::asio::read(cliConn, buffer.prepare(bytes_to_read),
            //                                                       ec);
            //    std::cout << "字节数: " <<bytes_transferred << std::endl;
            //    // std::cout << "数据读取完毕"<< std::endl;
            //     if (ec && ec != boost::asio::error::eof) {
            //         // 出现错误，不是EOF，打印错误信息然后跳出循环
            //         PRINT_WITH_TIME("Error on receive from client: %s" ,ec.message()) ;
            //         return;
            //     }

            //     buffer.commit(bytes_transferred); // 将数据从输入序列移动到输出序列

            // }
            // std::cout << "数据读取完毕"<< std::endl;
            // std::string data(std::istreambuf_iterator<char>(&buffer), {});

            // PRINT_WITH_TIME("客户端读取到的数据：%s",data);
            boost::asio::streambuf buffer;
           copyDataWithRateLimit(svrConn, cliConn, ClientSide, settings.uplimit,buffer);
           auto interop = protocol::CreateInterop(settings.protocol);
           interop.Dump(buffer, ClientSide, id, settings.quiet);
           
            
        }
#include"delayedWriter.h"
/*
    // 处理服务器消息的方法
    void handleServerMessage() {
        std::cout<<"服务端处理"<<std::endl;
        //DeferStop deferStop(std::bind(&PairedConnection::stop, this));
        DeferStop deferStop([this](){ this->stop();  });
        // 创建一个streambuf来缓存从服务器接收的数据
        boost::asio::streambuf buffer;
        std::ostream os(&buffer);
        std::istream is(&buffer);
        std::string data;
        std::getline(is, data);
        std::cout << data << std::endl;

        std::cout << data<<std::endl;
        // 创建一个DelayedWriter实例
        DelayedWriter delayedWriter(ioc, os, &stopSignal, std::chrono::seconds(1)); 
        // 创建一个Interop对象，用于处理数据  
        auto interop = protocol::CreateInterop(settings.protocol);

        // 创建一个新线程来处理数据的转储
        std::thread dumpThread([this, &interop, &buffer] {
            interop.Dump(buffer, protocol::ServerSide, id, settings.quiet);
        });

        // 使用copyDataWithRateLimit方法来处理从服务器到客户端的数据传输
        copyDataWithRateLimit(cliConn, svrConn, protocol::ServerSide, settings.downlimit);

        // 等待转储线程结束
        if (dumpThread.joinable()) {
            dumpThread.join();
        }
    }
*/
   // 处理服务器消息的方法
        void handleServerMessage() {


            DeferStop deferStop([this](){ this->stop();  });


            // boost::system::error_code ec;
            // boost::asio::streambuf buffer;

            // while (!stopFlag&&!ec) {
            //     // 尝试读取客户端数据，直到读取完毕或出现错误
                 
            //     std::size_t bytes_to_read = svrConn.available();
            //     if(bytes_to_read==0){
            //         break;
            //     }
            //     std::size_t bytes_transferred = boost::asio::read(svrConn, buffer.prepare(bytes_to_read ),
            //                                                       ec);
               

            //     if (ec && ec != boost::asio::error::eof) {
            //         // 出现错误，不是EOF，打印错误信息然后跳出循环
            //         PRINT_WITH_TIME("Error on receive from server: %s" ,ec.message()) ;
            //         return;
            //     }

            //     buffer.commit(bytes_transferred); // 将数据从输入序列移动到输出序列

            // }
            // std::string data(std::istreambuf_iterator<char>(&buffer), {});

            // PRINT_WITH_TIME("服务端读取到的数据：%s",data);  
            boost::asio::streambuf buffer; 
  #include <unistd.h>
            sleep(10);           
             copyDataWithRateLimit(cliConn, svrConn, protocol::ServerSide, settings.downlimit,buffer);
            auto interop = protocol::CreateInterop(settings.protocol);

            // 创建一个新线程来处理数据的转储
            std::thread dumpThread([this, &interop, &buffer] {
                interop.Dump(buffer, protocol::ServerSide, id, settings.quiet);
            });

            // 使用copyDataWithRateLimit方法来处理从服务器到客户端的数据传输
         

            // 等待转储线程结束
            if (dumpThread.joinable()) {
                dumpThread.join();
            }
        }


    // 处理连接的方法
    void process() {
        DeferStop deferStop([this](){ this->stop();  });
        //varDeferStop deferStop(std::bind(&PairedConnection::stop, this));
        boost::system::error_code ec;
        //unsigned short port_number = std::stoi(settings.remote);
        //svrConn.connect(boost::asio::ip::tcp::endpoint(boost::asio::ip::make_address(settings.remote), port_number), ec);
        std::string remote = settings.remote;
        size_t colon_position = remote.find(':');
        if (colon_position == std::string::npos) {
              PRINTLN_WITH_TIME(color::red("解析远程地址和端口号时出错: " + remote));
                  return;

        }
        //std::string ip_address_str = remote.substr(0, colon_position);
        std::string ip_address_str;
        if (remote.substr(0, colon_position) == "localhost") {
              ip_address_str = "127.0.0.1";

        }
        else {
              ip_address_str = remote.substr(0, colon_position);

        }
        std::string port_str = remote.substr(colon_position + 1);
        unsigned short port_number = 0;

        try {
              port_number = std::stoi(port_str);

        }
        catch (const std::invalid_argument& e) {
              PRINTLN_WITH_TIME(color::red("无效的端口号: " + port_str));
                  return;

        }
        catch (const std::out_of_range& e) {
              PRINTLN_WITH_TIME(color::red("端口号超出范围: " + port_str));
                  return;

        }
        //svrConn.connect(boost::asio::ip::tcp::endpoint(boost::asio::ip::make_address(ip_address_str), port_number), ec);
        try {
              //std::cout<<ip_address_str<<":"<<port_str<<std::endl;
              svrConn.connect(boost::asio::ip::tcp::endpoint(boost::asio::ip::make_address(ip_address_str), port_number), ec);

        }
        catch (boost::system::system_error& e) {
              PRINTLN_WITH_TIME(color::red("无法解析IP地址: " + ip_address_str));
              return;

        }
        // 如果连接失败，打印错误信息
        if (ec) {
          std::cout<<ec.value()<<std::endl;
            PRINTLN_WITH_TIME(color::red((boost::format("[x][%d] Couldn't connect to server: %s") % id % ec.message()).str()));
            return;
        }
        PRINTLN_WITH_TIME(color::green((boost::format("[%d] Connected to server: %s") % id % svrConn.remote_endpoint()).str()));
        stater->AddConn(boost::lexical_cast<string>(id), svrConn.native_handle());
        // 在后台启动一个新的线程来处理从服务器接收的消息
       // thread t([this] {
            //handleServerMessage();
       // });
        handleClientMessage();
    

        handleServerMessage();
       // t.join();
    }

    void stop() {
       // static atomic<bool> once(false);
        //static mutex mtx;
        //lock_guard<mutex> lock(mtx);
        if (!stopped.exchange(true)) {
           
           // stopSignal.cancel();
           
            stater->DelConn(boost::lexical_cast<string>(id));

            if (cliConn.is_open()) {
                PRINTLN_WITH_TIME(color::blue((boost::format("[%d] Client connection closed") % id).str()));
                cliConn.close();
            }
         
            if (svrConn.is_open()) {
                PRINTLN_WITH_TIME(color::blue((boost::format("[%d] Server connection closed") % id).str()));
                svrConn.close();
            }
        }
    }
private:
    // 连接的id
    int id;
    std::atomic<bool> stopped{false}; // 改为非静态成员，每个实例一个状态变量
    ip::tcp::socket cliConn;
    ip::tcp::socket svrConn;
    //boost::asio::steady_timer stopSignal;
    std::atomic<bool> stopChan;
    // 停止标志
    bool stopFlag;
};


void startListener() {
   // std::shared_ptr<Stater> s=stater;
   stater = NewStater( NewConnCounter() , NewStatPrinter(statInterval));
  
    thread t([&stater]{
        stater->Start();
        });
    t.detach();
    ip::tcp::acceptor acceptor(ioc, ip::tcp::endpoint(ip::make_address(settings.local_host), settings.local_port));
   PRINT_WITH_TIME("Listening on %s...\n", acceptor.local_endpoint().address().to_string().c_str());

    int connIndex = 0;
    while (true) {
   
        ip::tcp::socket cliConn(ioc);
        boost::system::error_code ec;
        acceptor.accept(cliConn, ec);
        if (ec) {
            PRINTLN_WITH_TIME(color::red((boost::format("server: accept: %s") % ec.message()).str()));
            break;
        }

        connIndex++;
      
        PRINTLN_WITH_TIME(color::green((boost::format("[%d] Accepted from: %s") % connIndex % cliConn.remote_endpoint()).str()));

   
        PairedConnection* pconn = new PairedConnection(connIndex, move(cliConn),ioc);
       // thread t1([pconn]{
            pconn->process();
          //  delete pconn;
          //  });
        //t1.detach();
        
    }
}
#endif // _CONN_H