
        
            
#ifndef DELAYED_WRITER_H // 使用 #ifndef 和 #define 宏来防止头文件被重复包含
#define DELAYED_WRITER_H

#include <boost/asio.hpp>
#include <iostream>
#include <functional>
#include <memory>
#include <chrono>

class DelayedWriter {
public:
    DelayedWriter(boost::asio::io_context& io_context, std::ostream& output, boost::asio::steady_timer *time,boost::asio::steady_timer::duration delay)
        : io_context_(io_context), output_(output), timer_(time),delay_(delay) {}

    void write(const std::string& data) {
        if (delay_.count() == 0) {
            output_ << data;
            return;
        }

        timer_->expires_after(delay_);
        timer_->async_wait([this, data](const boost::system::error_code& error) {
            if (!error) {
                output_ << data;
            }
        });
    }

    void stop() {
        timer_->cancel();
    }

private:
    boost::asio::io_context& io_context_;
    std::ostream& output_;
    boost::asio::steady_timer::duration delay_;
    boost::asio::steady_timer *timer_;
};


#endif // 结束头文件保护
