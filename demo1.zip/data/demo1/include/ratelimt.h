
                 
#ifndef RATELIMT_H
#define RATELIMT_H
#include <boost/asio.hpp>
#include <boost/asio/steady_timer.hpp>
#include <iostream>
#include <chrono>

class rate_limited_socket {
public:
    rate_limited_socket(boost::asio::ip::tcp::socket& socket, int64_t limit)
        : socket_(socket),
          limit_(limit),
          tokens_(limit),
          last_refill_(std::chrono::steady_clock::now()),
          refill_period_(std::chrono::seconds(1)),
          timer_(socket.get_executor()) {} // 修改这里

    template <typename MutableBufferSequence>
    size_t readSome(const MutableBufferSequence& buffers) {
        refill_tokens();
        auto bytes_to_read = std::min(boost::asio::buffer_size(buffers),  static_cast<std::size_t>(tokens_));
        if (bytes_to_read > 0) {
            auto bytes_read = socket_.read_some(boost::asio::buffer(buffers, bytes_to_read));
            tokens_ -= bytes_read;
            return bytes_read;
        }
        timer_.expires_from_now(refill_period_);
        timer_.wait();
        return 0;
    }

private:
    void refill_tokens() {
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_refill_).count();
        auto tokens_to_add = elapsed * limit_;
        tokens_ = std::min(tokens_ + tokens_to_add, limit_);
        last_refill_ = now;
    }

    boost::asio::ip::tcp::socket& socket_;
    int64_t limit_;
    int64_t tokens_;
    std::chrono::steady_clock::time_point last_refill_;
    std::chrono::steady_clock::duration refill_period_;
    boost::asio::steady_timer timer_;
};
#endif
