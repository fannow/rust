#ifndef INTEROP_H // 使用 #ifndef 和 #define 宏来防止头文件被重复包含
#define INTEROP_H
class Interop {
public:
    virtual void Dump(boost::asio::streambuf& buffer, const std::string& source, int id, bool quiet) {};
};
#endif