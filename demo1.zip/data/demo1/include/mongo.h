            
#ifndef MONGO_H 
#define MONGO_H

#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <map>
#include <iostream>
#include <iomanip>
#include <stdexcept>
// #include <bsoncxx/json.hpp>
// #include <bsoncxx/types.hpp>
// #include <bsoncxx/exception/exception.hpp>
// #include <boost/asio.hpp>
#include "interop.h"
// Constants
#define OpReply 1
#define OpUpdate 2001
#define OpInsert 2002
#define Reserved 2003
#define OpQuery 2004
#define OpGetMore 2005
#define OpDelete 2006
#define OpKillCursors 2007
#define OpCommand 2010
#define OpCommandReply 2011
#define OpMsg 2013


struct Packet {
    bool IsClientFlow;
    int MessageLength;
    int OpCode;
    std::stringstream Payload;
};


class MongoInterop:public Interop {
public:

    void ResolveClientPacket(Packet* pk);
    void Dump(boost::asio::streambuf& buffer, const std::string& source, int id, bool quiet);
    Packet* NewPacket(std::istream& r, const std::string& source);
    void ParsePacket(std::istream& r, Packet* p);
    std::string GetDirectionStr(bool isClient);
    int ReadInt32(std::stringstream& r);
    int64_t ReadInt64(std::stringstream& r);
    std::string ReadString(std::stringstream& r);
    std::string ReadBson2Json(std::stringstream& r);
};

void MongoInterop::Dump(boost::asio::streambuf& buffer, const std::string& source, int id, bool quiet) {
    std::istream r(&buffer);
    Packet* pk;
    while (true) {
        pk = NewPacket(r, source);
        if (pk == nullptr) {
            return;
        }
        if (pk->IsClientFlow) {
            ResolveClientPacket(pk);
        }
    }
}

void MongoInterop::ResolveClientPacket(Packet* pk) {
    std::string msg;
    switch (pk->OpCode) {
        case OpUpdate: {
            ReadInt32(pk->Payload);
            std::string fullCollectionName = ReadString(pk->Payload);
            ReadInt32(pk->Payload);
            std::string selector = ReadBson2Json(pk->Payload);
            std::string update = ReadBson2Json(pk->Payload);

            msg = " [Update] [coll:" + fullCollectionName + "] " + selector + " " + update;
            break;
        }
        case OpInsert: {
            ReadInt32(pk->Payload);
            std::string fullCollectionName = ReadString(pk->Payload);
            std::string command = ReadBson2Json(pk->Payload);

            msg = " [Insert] [coll:" + fullCollectionName + "] " + command;
            break;
        }
        case OpQuery: {
            ReadInt32(pk->Payload);
            std::string fullCollectionName = ReadString(pk->Payload);
            ReadInt32(pk->Payload);
            ReadInt32(pk->Payload);
            std::string command = ReadBson2Json(pk->Payload);
            std::string selector = ReadBson2Json(pk->Payload);

            msg = " [Query] [coll:" + fullCollectionName + "] " + command + " " + selector;
            break;
        }
        case OpCommand: {
            std::string database = ReadString(pk->Payload);
            std::string commandName = ReadString(pk->Payload);
            std::string metaData = ReadBson2Json(pk->Payload);
            std::string commandArgs = ReadBson2Json(pk->Payload);
            std::string inputDocs = ReadBson2Json(pk->Payload);

            msg = " [Commend] [DB:" + database + "] [Cmd:" + commandName + "] " + metaData + " " + commandArgs + " " + inputDocs;
            break;
        }
        case OpGetMore: {
            ReadInt32(pk->Payload);
            std::string fullCollectionName = ReadString(pk->Payload);
            int numberToReturn = ReadInt32(pk->Payload);
            int64_t cursorId = ReadInt64(pk->Payload);

            msg = " [Query more] [coll:" + fullCollectionName + "] [num of reply:" + std::to_string(numberToReturn) + "] [cursor:" + std::to_string(cursorId) + "]";
            break;
        }
        case OpDelete: {
            ReadInt32(pk->Payload);
            std::string fullCollectionName = ReadString(pk->Payload);
            ReadInt32(pk->Payload);
            std::string selector = ReadBson2Json(pk->Payload);

            msg = " [Delete] [coll:" + fullCollectionName + "] " + selector;
            break;
        }
        case OpMsg:
            return;
        default:
            return;
    }

    std::cout << GetDirectionStr(true) << msg << std::endl;
}



Packet* MongoInterop::NewPacket(std::istream& r, const std::string& source) {
    // 这里应该是创建一个新的Packet对象，并从输入流中读取数据填充它
    Packet* p = new Packet();
    ParsePacket(r, p);
    if (source == "SERVER") {
        p->IsClientFlow = false;
    } else {
        p->IsClientFlow = true;
    }
    return p;
}

void MongoInterop::ParsePacket(std::istream& r, Packet* p) {
    // 这里应该是解析输入流中的数据包头部，并读取负载数据
    char header[16];
    r.read(header, 16);
    int payloadLen = *reinterpret_cast<int*>(&header[0]) - 16;
    p->MessageLength = payloadLen;
    if (payloadLen != 0) {
        char* payload = new char[payloadLen];
        r.read(payload, payloadLen);
        p->Payload << std::string(payload, payloadLen);
        delete[] payload;
    }
}

std::string MongoInterop::GetDirectionStr(bool isClient) {
    // 这里应该是根据数据包流向返回相应的字符串表示
    return isClient ? "| cli -> ser |" : "| ser -> cli |";
}

int MongoInterop::ReadInt32(std::stringstream& r) {
    // 这里应该是从stringstream中读取一个32位整数
    int n;
    r.read(reinterpret_cast<char*>(&n), sizeof(n));
    return n;
}

int64_t MongoInterop::ReadInt64(std::stringstream& r) {
    // 这里应该是从stringstream中读取一个64位整数
    int64_t n;
    r.read(reinterpret_cast<char*>(&n), sizeof(n));
    return n;
}

std::string MongoInterop::ReadString(std::stringstream& r) {
    // 这里应该是从stringstream中读取一个以null结尾的字符串
    std::string result;
    char c;
    while (r.get(c) && c != '\0') {
        result += c;
    }
    return result;
}

std::string MongoInterop::ReadBson2Json(std::stringstream& r) {
    // 这里应该是将从stringstream中读取的BSON数据转换为JSON字符串
    int docLen = ReadInt32(r);
    if (docLen == 0) {
        return "";
    }

    std::string docBytes;
    docBytes.resize(docLen);

    r.read(&docBytes[0], docLen);

    // bsoncxx::document::view bsnView(reinterpret_cast<uint8_t*>(&docBytes[0]), docLen);

    // return bsoncxx::to_json(bsnView);

    return "";
}
#endif

        