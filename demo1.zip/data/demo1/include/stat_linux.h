
/*************************************************************************
        > File Name: include/stat_linux.h
        > Author: username
        > Mail: 111111111@qq.com
        > Created Time: Mon Mar 11 16:02:05 2024
 ************************************************************************/

#ifndef STAT_LINUX_H // 使用 #ifndef 和 #define 宏来防止头文件被重复包含
#define STAT_LINUX_H
 // #pragma once // 删除 #pragma once 指令
#include <iostream>
#include <map>
#include <mutex>
#include <vector>
#include <chrono>
#include <thread>
#include <shared_mutex> // 引用 shared_mutex 的头文件
#include <boost/format.hpp> // 引用 boost.format 库
#include "settings.h"
#include <algorithm> 
#include"stat.h"
#include <boost/asio.hpp> // 引用 boost.asio 库
#include"tcpstat_linux.h"


// 定义一个 StatPrinter 类，继承自 Stater 接口
class StatPrinter : public Stater {
private:
    boost::asio::io_context io_context;
    std::chrono::milliseconds duration; // 打印的间隔
    std::map<std::string, boost::asio::ip::tcp::socket*> conns; // 存储连接，使用 boost.asio 库的 socket 类型
    std::map<std::string, TcpInfo*> prev; // 存储上一次的统计信息
    std::shared_mutex lock; // 读写锁
public:
    // 构造函数，接受一个 std::chrono::milliseconds 类型的参数 duration
    StatPrinter(std::chrono::milliseconds duration) {
        this->duration = duration;
    }

    // 添加连接的方法，接受一个字符串作为键，和一个 TCP 套接字的指针作为值
    void AddConn(std::string key, boost::asio::ip::tcp::socket* conn) { // 使用 boost.asio 库的 socket 类型
        std::unique_lock<std::shared_mutex> guard(lock); // 加写锁
        conns[key] = conn; // 添加键值对
    }

    // 删除连接的方法，接受一个字符串作为键
    void DelConn(std::string key) {
        std::unique_lock<std::shared_mutex> guard(lock); // 加写锁
        conns.erase(key); // 删除 conns 中的键值对
        prev.erase(key); // 删除 prev 中的键值对
    }

    // 开始方法，创建一个定时器，每隔 duration 打印一次统计信息
    void Start() override {
        
        // 创建一个定时器，使用 std::chrono::steady_clock 作为时钟源
        auto timer = boost::asio::steady_timer(io_context, duration); // 使用 boost.asio 库的 steady_timer 类型
        // 设置定时器的回调函数，使用 lambda 表达式
        timer.async_wait([this](const boost::system::error_code& ec) {
            // 如果没有错误，就打印统计信息
            if (!ec) {
                this->print();
            }
            // 否则，输出错误信息
            else {
                std::cout << boost::str(boost::format("Timer error: %1%\n") % ec.message()); // 使用 boost.format 库和 std::cout 来格式化输出
            }
        });
        // 运行 io_context，开始定时器
        io_context.run();
    }

    // 结束方法，停止定时器，打印最后一次的统计信息
    void Stop() override {
        // 停止 io_context，取消定时器
         io_context.stop();
        // 打印最后一次的统计信息
        this->print();
    }

    // 构建表格的方法，返回一个二维字符串向量，表示表格的每一行
    std::vector<std::vector<std::string>> buildRows() {
        std::vector<std::string> keys; // 存储所有的键
        std::map<std::string, TcpInfo*> infos; // 存储当前的统计信息
        std::shared_lock<std::shared_mutex> guard(lock); // 加读锁
        auto prev = this->prev; // 复制 prev 的内容
        for (auto& pair : conns) { // 遍历 conns 中的键值对
            auto key = pair.first; // 获取键
            auto conn = pair.second; // 获取值
            TcpInfo* info; // 定义一个 TcpInfo 的指针
            std::error_code ec; // 定义一个错误码
            info = GetTcpInfo(conn, ec); // 获取统计信息
            if (ec) { // 如果有错误
                std::cout << boost::str(boost::format("GetTcpInfo: %1%\n") % ec.message()); // 使用 boost.format 库和 std::cout 来格式化输出
                continue; // 跳过这个键值对
            }

            keys.push_back(key); // 将键添加到 keys 向量中
            infos[key] = info; // 将键值对添加到 infos 映射中
        }
        this->prev = infos; // 更新 prev 的内容
        guard.unlock(); // 解锁

        std::vector<std::vector<std::string>> rows; // 定义一个二维字符串向量，用于存储表格的每一行
        auto now = std::chrono::system_clock::now(); // 获取当前的时间点
        std::time_t now_c = std::chrono::system_clock::to_time_t(now);
        std::sort(keys.begin(), keys.end()); // 对 keys 向量进行排序
        for (auto& key : keys) { // 遍历 keys 向量中的每个键
            auto info = infos[key]; // 获取当前的统计信息
            if (!info) { // 如果为空
                continue; // 跳过这个键
            }

            std::string rate; // 定义一个字符串，用于存储重传率
            auto pinfo = prev[key]; // 获取上一次的统计信息
            if (pinfo) { // 如果不为空
                rate = boost::str(boost::format("%.2f") % GetRetransRate(*pinfo, *info)); // 使用 boost.format 库来格式化字符串
            }
            else { // 如果为空
                rate = "-"; // 使用 "-" 表示无法计算
            }
            auto [rtt, rttv] = GetRTT(*info); // 获取往返时延和方差
            // 将当前的时间点、连接的标识符、重传率、往返时延和方差组成一个字符串向量，添加到 rows 向量中
          
            rows.push_back({ boost::str(boost::format("%1%") % now_c), key, rate, boost::str(boost::format("%1%") % rtt), boost::str(boost::format("%1%") % rttv) });
                }

            return rows; // 返回 rows 向量
        }

   
void print() {
    auto rows = this->buildRows(); // 获取表格的每一行
    if (rows.empty()) { // 如果为空
        std::cout << "没有可用的统计数据。\n";
        return; // 直接返回
    }

    // 打印表头
    std::cout << "Timestamp\tConnection\tRetransRate(%)\tRTT(ms)\tRTT/Variance(ms)\n";

    // 遍历并打印每一行数据
    for (auto& row : rows) {
        for (auto& col : row) {
            std::cout << col << "\t"; // 使用制表符分隔每个字段
        }
        std::cout << std::endl; // 每行结束后换行
    }
}

    };

    // 定义一个 NewStatPrinter 函数，接受一个 std::chrono::milliseconds 类型的参数 duration，并返回一个 Stater 接口的指针
    Stater* NewStatPrinter(std::chrono::milliseconds duration) {
        // 检查全局变量 settings 中的 Stat 字段是否为 false
        if (!settings.stat) {
            // 如果 Stat 字段为 false，则返回一个 NilPrinter 实例，表示不进行统计打印
            return new NilPrinter();
        }

        // 否则，返回一个 StatPrinter 实例，表示进行统计打印
        return new StatPrinter(duration);
    }
#endif // 添加 #endif 宏