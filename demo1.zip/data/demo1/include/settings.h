
            
/*************************************************************************
        > File Name: include/settings.h
        > Author: username
        > Mail: 111111111@qq.com
        > Created Time: Mon Mar 11 13:27:26 2024
 ************************************************************************/

#ifndef SETTINGS_H
#define SETTINGS_H
#pragma once
#include<iostream>
#include <string>
#include <boost/chrono.hpp>
// 定义一个名为 Settings 的结构体类型，它用于保存代理的配置选项
struct Settings {
	std::string remote;    // 远程地址，格式为 host:port
	std::string local_host; // 本地地址，用于监听
	int local_port;         // 本地端口，用于监听
	boost::chrono::milliseconds delay; // 转发数据包的延迟
	std::string protocol;  // 协议类型，目前支持 http2, grpc, redis, mongodb 和 mqtt
	bool stat;             // 是否开启统计功能
	bool quiet;            // 是否开启静默模式，只打印连接开启/关闭和统计信息
	int64_t uplimit;       // 上行速度限制，单位为字节/秒
	int64_t downlimit;     // 下行速度限制，单位为字节/秒
};

// 定义一个全局变量，用于保存代理的设置
Settings settings;

// 定义一个名为 saveSettings 的函数，它接收一些参数，并将它们赋值给 settings 变量
void saveSettings(std::string localHost, int localPort, std::string remote,  boost::chrono::milliseconds delay,
	std::string protocol, bool stat, bool quiet, int64_t upLimit, int64_t downLimit) {
	// 如果 localHost 不为空，将它赋值给 settings.LocalHost
		settings.local_host = localHost;
	// 如果 localPort 不为零，将它赋值给 settings.LocalPort
		settings.local_port = localPort;
	// 如果 remote 不为空，将它赋值给 settings.Remote
		settings.remote = remote;
	// 将 delay 赋值给 settings.Delay
	settings.delay = delay;
	// 将 protocol 赋值给 settings.Protocol
	settings.protocol = protocol;
	// 将 stat 赋值给 settings.Stat
	settings.stat = stat;
	// 将 quiet 赋值给 settings.Quiet
	settings.quiet = quiet;
	// 将 upLimit 赋值给 settings.UpLimit
	settings.uplimit = upLimit;
	// 将 downLimit 赋值给 settings.DownLimit
	settings.downlimit = downLimit;
}


#endif
            
