
/*************************************************************************
        > File Name: conter.h
        > Author: username
        > Mail: 111111111@qq.com
        > Created Time: Mon Mar 11 16:03:26 2024
 ************************************************************************/

#ifndef CONTER_H
#define CONTER_H
#include <iostream>
#include <map>
#include <mutex>
#include <atomic>
#include <chrono>
#include <fmt/color.h>
#include <fmt/core.h>
#include "stat.h"

// 定义一个 connCounter 类，继承自 Stater 接口
class connCounter : public Stater {
private:
    std::atomic<int64_t> total; // 总连接数
    std::atomic<int64_t> concurrent; // 并发连接数
    std::atomic<int64_t> max; // 最大连接数
    std::map<std::string, std::chrono::time_point<std::chrono::steady_clock>> conns; // 连接的开始时间，以字符串为键
    std::chrono::duration<double> maxLifetime; // 最大连接存活时间
    std::mutex lock; // 互斥锁，用于保护 conns 的访问
public:
    // 构造函数，初始化数据
    connCounter() {
        total = 0;
        concurrent = 0;
        max = 0;
        maxLifetime = std::chrono::duration<double>(0);
    }

    // 添加连接的方法，接受一个字符串作为键，和一个 TCP 连接的指针（这里不使用，只为了和 Go 代码保持一致）
    void AddConn(std::string key, void* conn) {
        total++; // 原子增加总连接数
        int64_t val = ++concurrent; // 原子增加并发连接数，并返回当前值
        int64_t maxVal = max.load(); // 原子读取最大连接数
        if (val > maxVal) {
            max.compare_exchange_strong(maxVal, val); // 如果当前并发数大于最大数，就尝试原子替换最大数
        }

        std::lock_guard<std::mutex> guard(lock); // 加锁，保护 conns 的访问
        conns[key] = std::chrono::steady_clock::now(); // 记录连接的开始时间
    }

    // 删除连接的方法，接受一个字符串作为键
    void DelConn(std::string key) {
        concurrent--; // 原子减少并发连接数

        std::lock_guard<std::mutex> guard(lock); // 加锁，保护 conns 的访问
        auto it = conns.find(key); // 查找连接的开始时间
        if (it != conns.end()) { // 如果找到了
            std::chrono::duration<double> lifetime = std::chrono::steady_clock::now() - it->second; // 计算连接的存活时间
            if (lifetime > maxLifetime) { // 如果大于最大存活时间
                maxLifetime = lifetime; // 更新最大存活时间
            }
            conns.erase(it); // 删除连接的记录
        }
    }

    // 开始方法，什么也不做
    void Start() {
    }

    // 结束方法，输出统计结果
    void Stop() {
        std::lock_guard<std::mutex> guard(lock); // 加锁，保护 conns 的访问
        for (auto& pair : conns) { // 遍历所有连接
            std::chrono::duration<double> lifetime = std::chrono::steady_clock::now() - pair.second; // 计算连接的存活时间
            if (lifetime > maxLifetime) { // 如果大于最大存活时间
                maxLifetime = lifetime; // 更新最大存活时间
            }
        }

        std::cout << std::endl;
        fmt::print(fmt::fg(fmt::color::white) | fmt::emphasis::bold, "Connection stats (client -> tproxy -> server):\n");
        fmt::print(fmt::fg(fmt::color::white) | fmt::emphasis::bold, "  Total connections: {}\n", total.load());
        fmt::print(fmt::fg(fmt::color::white) | fmt::emphasis::bold, "  Max concurrent connections: {}\n", max.load());
        fmt::print(fmt::fg(fmt::color::white) | fmt::emphasis::bold, "  Max connection lifetime: {}\n", maxLifetime.count());
    }
};
// 定义一个 NewConnCounter 函数，返回一个 Stater 接口的指针
Stater* NewConnCounter() {
    // 使用 new 关键字来动态分配内存，并调用 connCounter 的构造函数
    // 这样可以返回一个指向 connCounter 对象的指针，而不是一个局部变量
    // 这也可以避免对象的拷贝或移动，提高效率
    // 但是，这也意味着需要在使用完后，使用 delete 关键字来释放内存，防止内存泄漏
    return new connCounter();
}


#endif