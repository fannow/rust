#scl enable devtoolset-10 bash

#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib
g++ main.cpp -std=c++20 -lfmt -lboost_program_options -lpthread -lprotobuf -lnghttp2 -g


#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib   刷新库
