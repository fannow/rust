           
#include <iostream>
#include <boost/asio.hpp>
#include <boost/program_options.hpp>
#include <boost/thread.hpp>
#include <boost/chrono.hpp>
#include "include/settings.h"
#include "include/conn.h"

using namespace std;
using namespace boost::asio;
using namespace boost::program_options;



int main(int argc, char* argv[]) {
    
    //Settings settings;
    options_description desc("Options");
    desc.add_options()
        ("help,h", "Show help message")
        ("local-port,p", value<int>()->default_value(0), "Local port to listen on, default to pick a random port")
        ("local-host,l", value<string>()->default_value("::"),"Local address to listen on")
        ("remote,r", value<string>(), "Remote address (host:port) to connect")
        ("delay,d", value<int>()->default_value(0), "The delay to relay packets (in milliseconds)")
        ("protocol,t", value<string>()->default_value(""), "The type of protocol, currently support http2, grpc, redis, mongodb and mqtt")
        ("stat,s", value<bool>()->default_value(false), "Enable statistics")
        ("quiet,q", value<bool>()->default_value(false), "Quiet mode, only prints connection open/close and stats, default false")
        ("up-limit,up", value<int64_t>()->default_value(0), "Upward speed limit(bytes/second)")
        ("down-limit,down", value<int64_t>()->default_value(0), "Downward speed limit(bytes/second)");

    variables_map vm;
    store(parse_command_line(argc, argv, desc), vm);
    notify(vm);

    if (vm.count("help")) {
        cout << desc << endl;
        return 0;
    }

    if (!vm.count("remote")) {
        cerr << "\033[1;31m[x] Remote target required\033[0m" << endl;
        cout << desc << endl;
        return 1;
    }

    saveSettings(vm["local-host"].as<string>(), vm["local-port"].as<int>(), vm["remote"].as<string>(), boost::chrono::milliseconds(vm["delay"].as<int>()), vm["protocol"].as<string>(), vm["stat"].as<bool>(), vm["quiet"].as<bool>(), vm["up-limit"].as<int64_t>(), vm["down-limit"].as<int64_t>());

  /*  try {
        startListener();
    }
    catch (exception& e) {
        cerr << "\033[1;31m[x] Failed to start listener: " << e.what() << "\033[0m" << endl;
        return 1;
    }*/
     startListener();
    return 0;
}

       
